var config = {  
    map: {
        "*": {      
            'colorjoe': 'Codazon_ThemeOptions/js/colorjoe'            
        }
    },
     paths: {
        onecolor: 'Codazon_ThemeOptions/js/onecolor'
    } 
};
 
