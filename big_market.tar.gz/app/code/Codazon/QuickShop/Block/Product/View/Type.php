<?php
namespace Codazon\QuickShop\Block\Product\View;
class Type extends \Magento\Catalog\Block\Product\View\AbstractView
{
	
}